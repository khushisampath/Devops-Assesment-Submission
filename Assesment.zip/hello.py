#!/usr/bin/env python3
"""
Simple hello world script for DevOps assessment
"""

def main():
    print("Hello, DevOps!")

if __name__ == "__main__":
    main()
