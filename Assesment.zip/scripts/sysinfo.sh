#!/bin/bash

# DevOps Assessment - System Information Script
# Displays current user, date, and disk usage

echo "=== System Information ==="
echo ""

echo "Current User:"
whoami
echo ""

echo "Current Date:"
date
echo ""

echo "Disk Usage:"
df -h
echo ""

echo "=== End of System Information ==="
